# ChessGame

The chess application consists of two modes: playing against a friend in the same browser and playing against the computer, which utilizes the Stockfish REST API from https://stockfish.online/

Images for pieces used from Lichess official repo: https://github.com/lichess-org

Live version: https://awsomecstutorials.github.io/chess-game/

Tutorial can be found on FreeCodeCamp youtube channel: https://youtu.be/fJIsqZmQVZQ
